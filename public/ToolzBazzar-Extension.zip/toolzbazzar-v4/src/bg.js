/**
 * Chrome Extension Background Script
 * Purpose: Handle service worker functionality for ToolzBazzar Google Flow
 * Version: 12.0.0
 * 
 * Features:
 * - Plan-based credentials - no OAuth required
 * - Gets Google Flow credentials and cookies from user's subscribed plan
 * - Auto-injects cookies for labs.google domain
 * - Auto-fills login form on Google Flow
 * - Security: Clears cookies when subscription is inactive
 * - Security: Clears cookies when extension is disabled/uninstalled
 * - Restrictions: Hides premium models, 4K upscaling, limits outputs to 1
 */

const API_BASE = 'https://flow-forge-ai-10.lovable.app';
const GOOGLE_FLOW_URL = 'https://labs.google/fx/tools/flow';
const ALLOWED_DOMAIN = 'labs.google';

// Track the specific tab where Google Flow is opened
let googleFlowTabId = null;
let isTabActive = false;

// Subscription check interval (every 5 minutes)
const SUBSCRIPTION_CHECK_INTERVAL = 5 * 60 * 1000;
let subscriptionCheckTimer = null;

// Heartbeat interval (every 30 seconds) - for real-time status tracking
const HEARTBEAT_INTERVAL = 30 * 1000;
let heartbeatTimer = null;
let deviceId = null;

// Listen for messages from content scripts or popup
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    console.log('[Background] Message received:', request.action);
    
    if (request.action === 'getGoogleToken') {
        handleGoogleTokenRequest(request, sender, sendResponse);
        return true;
    }
    
    if (request.action === 'openGoogleFlow') {
        handleOpenGoogleFlow(request, sender, sendResponse);
        return true;
    }
    
    if (request.action === 'checkTabStatus') {
        sendResponse({ 
            isActive: isTabActive, 
            tabId: googleFlowTabId 
        });
        return true;
    }
    
    if (request.action === 'injectCookies') {
        injectCookies(request.cookies)
            .then(result => sendResponse({ success: true, result }))
            .catch(error => sendResponse({ success: false, error: error.message }));
        return true;
    }
    
    return false;
});

// Listen for tab updates to track navigation
chrome.tabs.onUpdated.addListener(async (tabId, changeInfo, tab) => {
    if (tabId === googleFlowTabId && changeInfo.url) {
        if (!changeInfo.url.includes('labs.google')) {
            console.log('[Background] User navigated away from Google Flow');
            googleFlowTabId = null;
            isTabActive = false;
        }
    }
});

/**
 * Handle Google Token request
 * Gets plan-based credentials and cookies from API
 */
async function handleGoogleTokenRequest(request, sender, sendResponse) {
    try {
        const response = await fetch(`${API_BASE}/api/google-token`, {
            method: 'GET',
            credentials: 'include',
            headers: getApiHeaders()
        });
        
        const data = await response.json();
        
        if (data.status === 'success') {
            sendResponse({ 
                success: true, 
                google_email: data.google_flow.email,
                google_password: data.google_flow.password,
                cookies: data.cookies || null,
                proxy_ip: data.proxy_ip || null,
                labs_url: data.labs_url || GOOGLE_FLOW_URL,
                subscription: data.subscription
            });
        } else {
            sendResponse({ 
                success: false, 
                error: data.message || 'Failed to get credentials',
                status: data.status
            });
        }
    } catch (err) {
        console.error('[Background] Google token error:', err);
        sendResponse({ 
            success: false, 
            error: 'Network error: ' + err.message 
        });
    }
}

/**
 * Handle Open Google Flow request
 * Gets credentials and cookies, injects cookies, then opens Google Flow
 */
async function handleOpenGoogleFlow(request, sender, sendResponse) {
    console.log('[Background] Opening Google Flow...');
    
    try {
        // Check if Google Flow is already open
        if (googleFlowTabId && isTabActive) {
            try {
                const existingTab = await chrome.tabs.get(googleFlowTabId);
                if (existingTab && existingTab.url && existingTab.url.includes('labs.google')) {
                    await chrome.tabs.update(googleFlowTabId, { active: true });
                    await chrome.windows.update(existingTab.windowId, { focused: true });
                    sendResponse({ 
                        success: true, 
                        tabId: googleFlowTabId, 
                        message: 'Google Flow already open' 
                    });
                    return;
                }
            } catch (e) {
                googleFlowTabId = null;
                isTabActive = false;
            }
        }
        
        // Step 1: Get credentials and cookies from API
        const response = await fetch(`${API_BASE}/api/google-token`, {
            method: 'GET',
            credentials: 'include',
            headers: getApiHeaders()
        });
        
        const data = await response.json();
        console.log('[Background] API response:', data.status);
        
        if (data.status !== 'success') {
            console.log('[Background] API error:', data.message);
            const tab = await chrome.tabs.create({ 
                url: GOOGLE_FLOW_URL,
                active: true
            });
            googleFlowTabId = tab.id;
            isTabActive = true;
            sendResponse({ 
                success: true, 
                tabId: tab.id, 
                warning: data.message || 'API error' 
            });
            return;
        }
        
        // Step 2: Store credentials for content script
        await chrome.storage.local.set({
            gf_credentials: {
                email: data.google_flow.email,
                password: data.google_flow.password,
                timestamp: Date.now()
            }
        });
        
        // Step 3: Inject cookies if available
        if (data.cookies && data.cookies.cookies && data.cookies.cookies.length > 0) {
            console.log('[Background] Injecting', data.cookies.cookies.length, 'cookies');
            try {
                await injectCookies(data.cookies.cookies);
                console.log('[Background] Cookies injected successfully');
            } catch (cookieError) {
                console.warn('[Background] Cookie injection failed:', cookieError.message);
            }
        }
        
        // Step 4: Open Google Flow tab
        const flowTab = await chrome.tabs.create({ 
            url: GOOGLE_FLOW_URL,
            active: true
        });
        
        googleFlowTabId = flowTab.id;
        isTabActive = true;
        
        console.log('[Background] Google Flow opened in tab:', flowTab.id);
        sendResponse({ 
            success: true, 
            tabId: flowTab.id,
            credentials: {
                email: data.google_flow.email
            },
            cookies_injected: data.cookies ? true : false
        });
        
    } catch (err) {
        console.error('[Background] Open Google Flow error:', err);
        try {
            const tab = await chrome.tabs.create({ 
                url: GOOGLE_FLOW_URL,
                active: true 
            });
            googleFlowTabId = tab.id;
            isTabActive = true;
            sendResponse({ success: true, tabId: tab.id, warning: 'Error: ' + err.message });
        } catch (tabErr) {
            sendResponse({ success: false, error: err.message });
        }
    }
}

/**
 * Inject cookies for labs.google domain
 */
async function injectCookies(cookies) {
    if (!cookies || cookies.length === 0) {
        throw new Error('No cookies to inject');
    }
    
    // Clean old cookies first
    await cleanOldCookies();
    
    const injectedCookies = [];
    let successCount = 0;
    let failCount = 0;
    
    for (const cookie of cookies) {
        try {
            const isHostPrefixed = cookie.name && cookie.name.startsWith('__Host-');
            const url = 'https://labs.google';
            
            const cookieDetails = {
                url: url,
                name: cookie.name,
                value: String(cookie.value),
                path: cookie.path || '/',
                secure: true,
                httpOnly: cookie.httpOnly || false,
                sameSite: cookie.sameSite || 'lax'
            };
            
            if (!isHostPrefixed) {
                cookieDetails.domain = '.labs.google';
            }
            
            // Set expiration (30 days default)
            if (cookie.expirationDate) {
                cookieDetails.expirationDate = cookie.expirationDate;
            } else {
                cookieDetails.expirationDate = Math.floor(Date.now() / 1000) + (86400 * 30);
            }
            
            await chrome.cookies.set(cookieDetails);
            successCount++;
            injectedCookies.push({
                name: cookie.name,
                path: cookie.path || '/'
            });
            
            console.log('[Background] Injected cookie:', cookie.name);
        } catch (error) {
            failCount++;
            console.error('[Background] Failed to inject cookie', cookie.name, ':', error);
        }
    }
    
    // Store injected cookies info for cleanup
    if (injectedCookies.length > 0) {
        await chrome.storage.local.set({ injected_cookies: injectedCookies });
    }
    
    console.log(`[Background] Successfully injected ${successCount} cookies (${failCount} failed)`);
    return { success: successCount, failed: failCount, cookies: injectedCookies };
}

/**
 * Clean old cookies from labs.google domain
 */
async function cleanOldCookies() {
    try {
        const cookies = await chrome.cookies.getAll({ domain: ALLOWED_DOMAIN });
        console.log(`[Background] Cleaning ${cookies.length} old cookies`);
        
        for (const cookie of cookies) {
            const url = `https://${ALLOWED_DOMAIN}${cookie.path}`;
            await chrome.cookies.remove({ url: url, name: cookie.name });
        }
        
        await chrome.storage.local.remove('injected_cookies');
        
        return cookies.length;
    } catch (error) {
        console.error('[Background] Error cleaning old cookies:', error);
        throw error;
    }
}

// Log when background script loads
console.log('[Background] ToolzBazzar background script loaded v12.0.0 - With real-time status tracking');

// Extension version constant
const EXTENSION_VERSION = '12.0.0';

/**
 * Get API headers with extension version
 */
function getApiHeaders(extraHeaders = {}) {
    return {
        'Accept': 'application/json',
        'X-Extension-Version': EXTENSION_VERSION,
        ...extraHeaders
    };
}

/**
 * Check extension version against server
 */
async function checkExtensionVersion() {
    try {
        const manifest = chrome.runtime.getManifest();
        const currentVersion = manifest.version;
        
        console.log('[Background] Current extension version:', currentVersion);
        
        const response = await fetch(`${API_BASE}/api/extension-version?type=user`, {
            method: 'GET',
            headers: getApiHeaders()
        });
        
        const data = await response.json();
        
        if (data.status === 'success' && data.version) {
            console.log('[Background] Server extension version:', data.version);
            
            if (data.version !== currentVersion) {
                console.log('[Background] Version mismatch! Update required.');
                showUpdateNotification(currentVersion, data.version);
            } else {
                console.log('[Background] Version is up to date.');
            }
        }
    } catch (err) {
        console.error('[Background] Version check failed:', err);
    }
}

/**
 * Show update notification
 */
function showUpdateNotification(currentVersion, latestVersion) {
    try {
        chrome.notifications?.create({
            type: 'basic',
            title: 'Extension Update Required',
            message: `Your extension (v${currentVersion}) is outdated. Please update to v${latestVersion} from your dashboard.`,
            priority: 2,
            requireInteraction: true
        });
    } catch (e) {
        console.warn('[Background] Notification error:', e);
    }
}

// Handle notification button clicks
chrome.notifications?.onButtonClicked?.addListener((notificationId, buttonIndex) => {
    if (buttonIndex === 0) {
        chrome.tabs.create({ url: `${API_BASE}/dashboard` });
    }
    chrome.notifications.clear(notificationId);
});

// Listen for version check requests from popup
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'checkVersion') {
        checkExtensionVersion().then(() => {
            sendResponse({ success: true });
        }).catch((err) => {
            sendResponse({ success: false, error: err.message });
        });
        return true;
    }
});

// ─────────────────────────────────────────────────────────────────────────
// SECURITY: Subscription Check & Cookie Cleanup
// ─────────────────────────────────────────────────────────────────────────

/**
 * Start periodic subscription check
 */
function startSubscriptionCheck() {
    // Clear existing timer
    if (subscriptionCheckTimer) {
        clearInterval(subscriptionCheckTimer);
    }
    
    // Check immediately
    checkSubscriptionStatus();
    
    // Then check periodically
    subscriptionCheckTimer = setInterval(checkSubscriptionStatus, SUBSCRIPTION_CHECK_INTERVAL);
    console.log('[Background] Subscription check started (every 5 minutes)');
}

/**
 * Check subscription status from server
 */
async function checkSubscriptionStatus() {
    try {
        const response = await fetch(`${API_BASE}/api/google-token`, {
            method: 'GET',
            credentials: 'include',
            headers: getApiHeaders()
        });
        
        const data = await response.json();
        
        if (data.status !== 'success' || !data.subscription || data.subscription.status !== 'active') {
            console.log('[Background] Subscription not active - cleaning cookies');
            await cleanupAllGoogleFlowData();
            
            // Show notification to user
            showSubscriptionExpiredNotification();
        } else {
            console.log('[Background] Subscription active - OK');
        }
    } catch (err) {
        console.error('[Background] Subscription check failed:', err);
    }
}

/**
 * Cleanup all Google Flow data - cookies, storage, session
 */
async function cleanupAllGoogleFlowData() {
    console.log('[Background] Cleaning up all Google Flow data...');
    
    try {
        // 1. Remove all cookies from labs.google domain
        const cookies = await chrome.cookies.getAll({ domain: ALLOWED_DOMAIN });
        console.log(`[Background] Removing ${cookies.length} cookies from ${ALLOWED_DOMAIN}`);
        
        for (const cookie of cookies) {
            try {
                const url = `https://${ALLOWED_DOMAIN}${cookie.path}`;
                await chrome.cookies.remove({ url: url, name: cookie.name });
            } catch (e) {
                console.warn('[Background] Failed to remove cookie:', cookie.name);
            }
        }
        
        // 2. Remove cookies from google.com domain that might be related
        const googleCookies = await chrome.cookies.getAll({ domain: '.google.com' });
        let googleRemoved = 0;
        for (const cookie of googleCookies) {
            // Only remove specific Google Flow related cookies
            if (cookie.name.includes('SID') || cookie.name.includes('HSID') || 
                cookie.name.includes('SSID') || cookie.name.includes('APISID') ||
                cookie.name.includes('SAPISID')) {
                try {
                    const url = `https://google.com${cookie.path}`;
                    await chrome.cookies.remove({ url: url, name: cookie.name });
                    googleRemoved++;
                } catch (e) {
                    // Ignore
                }
            }
        }
        console.log(`[Background] Removed ${googleRemoved} Google session cookies`);
        
        // 3. Clear extension storage
        await chrome.storage.local.remove(['gf_credentials', 'injected_cookies']);
        
        // 4. Reset tab tracking
        googleFlowTabId = null;
        isTabActive = false;
        
        console.log('[Background] Cleanup complete - all Google Flow data removed');
        
    } catch (err) {
        console.error('[Background] Cleanup error:', err);
    }
}

/**
 * Show subscription expired notification
 */
function showSubscriptionExpiredNotification() {
    try {
        chrome.notifications?.create({
            type: 'basic',
            title: 'Subscription Expired',
            message: 'Your subscription is no longer active. Google Flow access has been revoked.',
            priority: 2,
            requireInteraction: true
        });
    } catch (e) {
        console.warn('[Background] Notification error:', e);
    }
}

// Handle notification button clicks for subscription expired
chrome.notifications?.onButtonClicked?.addListener((notificationId, buttonIndex) => {
    if (buttonIndex === 0) {
        chrome.tabs.create({ url: `${API_BASE}/dashboard` });
    }
    chrome.notifications.clear(notificationId);
});

// ─────────────────────────────────────────────────────────────────────────
// SECURITY: Extension Disable/Uninstall Handler
// ─────────────────────────────────────────────────────────────────────────

/**
 * Handle extension suspend (when disabled)
 * This is called when the extension is disabled or the browser is closing
 */
chrome.runtime.onSuspend.addListener(async () => {
    console.log('[Background] Extension suspending - cleaning up cookies');
    await cleanupAllGoogleFlowData();
});

/**
 * Handle extension install/update - start subscription check
 */
chrome.runtime.onInstalled.addListener(async (details) => {
    console.log('[Background] Extension installed:', details.reason);
    
    if (details.reason === 'install') {
        // New install - start fresh
        await cleanupAllGoogleFlowData();
        startSubscriptionCheck();
    } else if (details.reason === 'update') {
        // Update - check subscription
        startSubscriptionCheck();
    }
    
    checkExtensionVersion();
});

/**
 * Handle extension startup
 */
chrome.runtime.onStartup.addListener(() => {
    console.log('[Background] Extension started');
    checkExtensionVersion();
    startSubscriptionCheck();
});

/**
 * Set uninstall URL - opens when extension is uninstalled
 * This will clean up server-side session
 */
chrome.runtime.setUninstallURL(`${API_BASE}/api/extension-uninstalled`, () => {
    // This URL is called when extension is uninstalled
    // The server can clean up any remaining session data
});

// Start subscription check when background script loads
startSubscriptionCheck();

// Start heartbeat for real-time status tracking
startHeartbeat();

console.log('[Background] ToolzBazzar background script loaded v12.0.0 - With real-time status tracking');

/**
 * Generate or retrieve device ID for heartbeat tracking
 */
async function getDeviceId() {
    if (deviceId) return deviceId;
    
    const result = await chrome.storage.local.get('wc_device_id');
    if (result.wc_device_id) {
        deviceId = result.wc_device_id;
    } else {
        deviceId = 'ext_' + Math.random().toString(36).substr(2, 9);
        await chrome.storage.local.set({ wc_device_id: deviceId });
    }
    return deviceId;
}

/**
 * Start heartbeat - sends periodic signals to server for online status
 */
function startHeartbeat() {
    if (heartbeatTimer) {
        clearInterval(heartbeatTimer);
    }
    
    console.log('[Background] Starting heartbeat for real-time status tracking');
    
    // Send initial heartbeat
    sendHeartbeat();
    
    // Then every 30 seconds
    heartbeatTimer = setInterval(sendHeartbeat, HEARTBEAT_INTERVAL);
}

/**
 * Stop heartbeat
 */
function stopHeartbeat() {
    if (heartbeatTimer) {
        clearInterval(heartbeatTimer);
        heartbeatTimer = null;
        console.log('[Background] Heartbeat stopped');
    }
}

/**
 * Send heartbeat to server
 */
async function sendHeartbeat() {
    try {
        const id = await getDeviceId();
        const manifest = chrome.runtime.getManifest();
        
        // Get OS info from navigator
        const userAgent = navigator.userAgent;
        let os = 'unknown';
        if (userAgent.indexOf('Win') !== -1) os = 'Windows';
        else if (userAgent.indexOf('Mac') !== -1) os = 'macOS';
        else if (userAgent.indexOf('Linux') !== -1) os = 'Linux';
        
        const response = await fetch(`${API_BASE}/api/extension-heartbeat`, {
            method: 'POST',
            credentials: 'include',
            headers: getApiHeaders({
                'Content-Type': 'application/json',
                'X-Device-Id': id
            }),
            body: JSON.stringify({
                device_id: id,
                device_name: 'Chrome Extension',
                extension_version: manifest.version,
                os: os,
                chrome_version: navigator.userAgent.match(/Chrome\/([0-9.]+)/)?.[1] || 'unknown'
            })
        });
        
        if (response.ok) {
            console.log('[Background] Heartbeat sent successfully');
        } else {
            console.warn('[Background] Heartbeat failed:', response.status);
        }
    } catch (error) {
        console.error('[Background] Heartbeat error:', error.message);
    }
}
