/**
 * Chrome Extension Popup Script
 * Purpose: Handle popup UI for Google Flow extension
 * Version: 12.0.0
 * 
 * Features:
 * - Plan-based credentials - no OAuth required
 * - Gets credentials from user's subscribed plan
 * - Cookie injection for auto-login
 */

const API_BASE = 'https://flow-forge-ai-10.lovable.app';
const GOOGLE_FLOW_URL = 'https://labs.google/fx/tools/flow';
const EXTENSION_VERSION = '12.0.0';

// Helper function to get API headers with version
function getApiHeaders(extraHeaders = {}) {
    return {
        'Accept': 'application/json',
        'X-Extension-Version': EXTENSION_VERSION,
        ...extraHeaders
    };
}

// Hidden user details - show ToolzBazzar info instead
const DISPLAY_NAME = 'ToolzBazzar';
const DISPLAY_EMAIL = 'support@toolzbazzar.com';

let isAuthenticated = false;
let userData = null;

// DOM Elements
let statusBox = null;
let errorBox = null;
let successBox = null;
let openFlowBtn = null;
let connectBtn = null;
let userInfo = null;

// Initialize when DOM is ready
document.addEventListener('DOMContentLoaded', function() {
    // Get DOM elements AFTER DOM is loaded
    statusBox = document.getElementById('statusBox');
    errorBox = document.getElementById('errorBox');
    successBox = document.getElementById('successBox');
    openFlowBtn = document.getElementById('openFlowBtn');
    connectBtn = document.getElementById('connectBtn');
    userInfo = document.getElementById('userInfo');
    
    // Add event listeners AFTER elements are available
    if (openFlowBtn) {
        openFlowBtn.addEventListener('click', openGoogleFlow);
    }
    if (connectBtn) {
        connectBtn.addEventListener('click', connectToBackend);
    }
    
    // Initialize - check authentication
    init();
});

function showLoading(text, subtext) {
    if (!statusBox || !openFlowBtn || !connectBtn) return;
    statusBox.style.display = 'block';
    statusBox.innerHTML = '<div class="status-icon"><span class="spinner"></span></div><div class="status-text">' + text + '</div><div class="status-sub">' + subtext + '</div>';
    openFlowBtn.style.display = 'none';
    connectBtn.style.display = 'none';
    errorBox.style.display = 'none';
    successBox.style.display = 'none';
}

function showAuthenticated(subscription) {
    if (!statusBox || !openFlowBtn || !connectBtn) return;
    
    let subText = 'Ready to open Google Flow';
    if (subscription && subscription.plan) {
        subText = 'Plan: ' + subscription.plan + ' | ' + subText;
    }
    
    statusBox.style.display = 'block';
    statusBox.innerHTML = '<div class="status-icon">✅</div><div class="status-text">Connected!</div><div class="status-sub">' + subText + '</div>';
    
    // Show user info with hidden details (ToolzBazzar)
    if (userInfo) {
        userInfo.style.display = 'block';
        userInfo.innerHTML = '<div class="user-name">' + DISPLAY_NAME + '</div><div class="user-email">' + DISPLAY_EMAIL + '</div>';
    }
    
    openFlowBtn.style.display = 'block';
    connectBtn.style.display = 'none';
    errorBox.style.display = 'none';
    successBox.style.display = 'none';
}

function showNotAuthenticated(message) {
    if (!statusBox || !openFlowBtn || !connectBtn) return;
    statusBox.style.display = 'block';
    statusBox.innerHTML = '<div class="status-icon">⚠️</div><div class="status-text">Not Connected</div><div class="status-sub">' + message + '</div>';
    if (userInfo) {
        userInfo.style.display = 'none';
    }
    openFlowBtn.style.display = 'none';
    connectBtn.style.display = 'block';
    errorBox.style.display = 'block';
    errorBox.textContent = message;
    successBox.style.display = 'none';
}

function showError(message) {
    if (!errorBox) return;
    errorBox.style.display = 'block';
    errorBox.textContent = message;
    successBox.style.display = 'none';
}

function showSuccess(message) {
    if (!successBox) return;
    successBox.style.display = 'block';
    successBox.textContent = message;
    errorBox.style.display = 'none';
}

async function init() {
    showLoading('Checking authentication...', 'Please wait');
    
    try {
        const response = await fetch(API_BASE + '/api/google-token', {
            method: 'GET',
            credentials: 'include',
            headers: getApiHeaders()
        });
        
        const data = await response.json();
        
        if (response.ok && data.status === 'success') {
            isAuthenticated = true;
            userData = data;
            showAuthenticated(data.subscription);
        } else if (data.status === 'not_logged_in') {
            showNotAuthenticated('Please login to ToolzBazzar.store first');
        } else {
            showNotAuthenticated(data.message || 'Authentication failed');
        }
    } catch (e) {
        console.error('Auth check error:', e);
        showNotAuthenticated('Connection error. Please try again.');
    }
}

async function connectToBackend() {
    showLoading('Connecting...', 'Opening ToolzBazzar.store');
    window.open(API_BASE + '/login?redirect=/dashboard', '_blank');
    showNotAuthenticated('Please login to ToolzBazzar.store, then refresh this popup.');
}

async function openGoogleFlow() {
    if (!isAuthenticated) {
        showError('Not authenticated. Please connect first.');
        return;
    }
    
    openFlowBtn.disabled = true;
    openFlowBtn.innerHTML = '<span class="spinner"></span>Opening Google Flow...';
    
    try {
        // Use background script to inject cookies and open Google Flow
        chrome.runtime.sendMessage(
            { action: 'openGoogleFlow' },
            function(response) {
                if (chrome.runtime.lastError) {
                    console.error('Runtime error:', chrome.runtime.lastError);
                    // Fallback: direct open
                    window.open(GOOGLE_FLOW_URL, '_blank');
                    showError('Cookie injection failed. Opened directly.');
                } else if (response && response.success) {
                    openFlowBtn.innerHTML = '✅ Opened!';
                    showSuccess('Google Flow opened!');
                } else {
                    showError(response?.error || 'Failed to open Google Flow');
                }
                
                setTimeout(function() {
                    if (openFlowBtn) {
                        openFlowBtn.disabled = false;
                        openFlowBtn.innerHTML = '🚀 Open Google Flow';
                    }
                }, 2000);
            }
        );
    } catch (e) {
        console.error('Open Google Flow error:', e);
        // Fallback: direct open
        window.open(GOOGLE_FLOW_URL, '_blank');
        showError('Error occurred. Please try again.');
        if (openFlowBtn) {
            openFlowBtn.disabled = false;
            openFlowBtn.innerHTML = '🚀 Open Google Flow';
        }
    }
}
