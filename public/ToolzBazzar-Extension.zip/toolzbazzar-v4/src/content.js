/**
 * Chrome Extension Content Script
 * Purpose: Handle communication for wakandaTools - ONLY on labs.google
 * Version: 12.0.0
 * 
 * Features:
 * - Private/Incognito mode only
 * - ONLY works on labs.google domain
 * - NO LOGOUT functionality
 * - Handles extension context invalidated errors gracefully
 * - RESTRICTS premium features (models, 4K upscaling, multiple outputs)
 */

// Check if extension context is valid
function isExtensionContextValid() {
    try {
        return typeof chrome !== 'undefined' && chrome.runtime && !!chrome.runtime.id;
    } catch (e) {
        return false;
    }
}

// Safe wrapper for chrome.runtime.sendMessage that handles context invalidated errors
function safeRuntimeMessage(message, callback) {
    // First check if context is valid
    if (!isExtensionContextValid()) {
        console.warn('[wakanda_bridge] Extension context invalidated before sendMessage');
        callback(null, 'Extension context invalidated');
        return;
    }
    
    try {
        chrome.runtime.sendMessage(message, function(response) {
            // Check for runtime errors
            if (chrome.runtime.lastError) {
                console.error('[wakanda_bridge] Runtime error:', chrome.runtime.lastError.message);
                callback(null, chrome.runtime.lastError.message);
                return;
            }
            callback(response, null);
        });
    } catch (error) {
        console.error('[wakanda_bridge] sendMessage error:', error.message);
        callback(null, error.message);
    }
}

// Only run on labs.google domain OR wakandacreative.store (for dashboard button)
if (window.location.hostname.includes('labs.google') || window.location.hostname.includes('wakandacreative.store')) {

    // =====================================================
    // Dummy wakandaTools to prevent errors in original code
    // =====================================================
    if (typeof wakandaTools === 'undefined') {
        window.wakandaTools = {
            sendMessage: function() { return Promise.resolve(); },
            create: function() { return null; },
            log: function() {},
            showStatus: function() {},
            qs: function() { return null; }
        };
    }

    // =====================================================
    // wakanda_bridge.js - Communication between page and extension
    // =====================================================

    (function() {
        'use strict';

        const GF_PING = 'GF_PING';
        const GF_PONG = 'GF_PONG';
        const GF_OPEN_FLOW = 'GF_OPEN_FLOW';
        const GF_OPEN_FLOW_RESULT = 'GF_OPEN_FLOW_RESULT';

        // Listen for messages from the webpage
        window.addEventListener('message', function(event) {
            // Only accept messages from the same window
            if (event.source !== window) return;
            
            const data = event.data;
            if (!data || typeof data !== 'object') return;
            
            console.log('[wakanda_bridge] Received message:', data.type);
            
            // Handle GF_PING - respond with GF_PONG to tell page extension is installed
            if (data.type === GF_PING) {
                console.log('[wakanda_bridge] Sending GF_PONG');
                window.postMessage({ type: GF_PONG }, '*');
                return;
            }
            
            // Handle GF_OPEN_FLOW - open Google Flow
            if (data.type === GF_OPEN_FLOW) {
                console.log('[wakanda_bridge] Opening Google Flow');
                openGoogleFlowFromPage();
                return;
            }
        });

        // Function to open Google Flow from page request
        function openGoogleFlowFromPage() {
            // Use safe wrapper for runtime message
            safeRuntimeMessage({ action: 'openGoogleFlow' }, function(response, error) {
                if (error) {
                    console.error('[wakanda_bridge] Error:', error);
                    
                    // Check if it's a context invalidated error
                    if (error.includes('Extension context invalidated') || error.includes('Extension was reloaded')) {
                        console.warn('[wakanda_bridge] Extension was reloaded, notifying page');
                        window.postMessage({ 
                            type: GF_OPEN_FLOW_RESULT, 
                            success: false, 
                            reason: 'Extension was reloaded. Please refresh the page and try again.',
                            needRefresh: true
                        }, '*');
                        return;
                    }
                    
                    // Fallback: direct open for other errors
                    console.log('[wakanda_bridge] Using fallback - direct open');
                    window.open('https://labs.google/fx/tools/flow', '_blank');
                    window.postMessage({ 
                        type: GF_OPEN_FLOW_RESULT, 
                        success: true,
                        fallback: true,
                        reason: error
                    }, '*');
                    return;
                }
                
                if (response && response.success) {
                    console.log('[wakanda_bridge] Google Flow opened successfully');
                    window.postMessage({ 
                        type: GF_OPEN_FLOW_RESULT, 
                        success: true 
                    }, '*');
                } else {
                    console.error('[wakanda_bridge] Failed to open:', response?.error);
                    window.postMessage({ 
                        type: GF_OPEN_FLOW_RESULT, 
                        success: false, 
                        reason: response?.error || 'Failed to open Google Flow'
                    }, '*');
                }
            });
        }

        console.log('[wakanda_bridge] Loaded successfully - v12.0.0');
    })();

    // =====================================================
    // FEATURE RESTRICTIONS - Hide premium features
    // =====================================================
    
    (function() {
        'use strict';
        
        // Restricted model names (these will be hidden)
        const RESTRICTED_MODELS = [
            'Veo 3.1 - Fast',
            'Veo 3.1 - Quality',
            'Veo 2 - Quality',
            'Veo 2 - Fast',
            'Veo 3 Fast',
            'Veo 3 Quality'
        ];
        
        // Restricted download options
        const RESTRICTED_DOWNLOADS = [
            'Upscaled 4K',
            '4K',
            'Upscaled (4K)'
        ];
        
        // Maximum outputs allowed
        const MAX_OUTPUTS = 1;
        
        /**
         * Hide restricted model options in dropdowns
         */
        function hideRestrictedModels() {
            // Find all buttons/spans that contain model names
            const allButtons = document.querySelectorAll('button, span, div');
            
            allButtons.forEach(element => {
                const text = element.textContent || element.innerText || '';
                
                // Check if this element contains a restricted model name
                RESTRICTED_MODELS.forEach(model => {
                    if (text.trim() === model || text.includes(model)) {
                        // Check if it's a selectable option
                        const parent = element.closest('[role="option"]');
                        if (parent) {
                            parent.style.display = 'none';
                            parent.setAttribute('data-wc-hidden', 'true');
                            console.log('[WC Restrict] Hidden model option:', model);
                        }
                    }
                });
            });
            
            // Also hide in dropdown menus
            const dropdownItems = document.querySelectorAll('[role="option"], [role="listitem"], .sc-62c7c21-3');
            dropdownItems.forEach(item => {
                const text = item.textContent || '';
                RESTRICTED_MODELS.forEach(model => {
                    if (text.includes(model)) {
                        item.style.display = 'none';
                        item.setAttribute('data-wc-hidden', 'true');
                    }
                });
            });
        }
        
        /**
         * Hide 4K upscaling options
         */
        function hide4KUpscaling() {
            const allElements = document.querySelectorAll('button, span, div, li');
            
            allElements.forEach(element => {
                const text = element.textContent || element.innerText || '';
                
                RESTRICTED_DOWNLOADS.forEach(download => {
                    if (text.includes(download) && text.length < 50) {
                        // Check if it's a download button/option
                        const parent = element.closest('button') || element.closest('[role="menuitem"]') || element.closest('li');
                        if (parent && !parent.getAttribute('data-wc-hidden')) {
                            parent.style.display = 'none';
                            parent.setAttribute('data-wc-hidden', 'true');
                            console.log('[WC Restrict] Hidden 4K option:', text.trim());
                        }
                    }
                });
            });
        }
        
        /**
         * Force output count to 1 and lock it
         */
        function forceSingleOutput() {
            // Find and disable "Outputs per prompt" selector
            const allButtons = document.querySelectorAll('button');
            
            allButtons.forEach(button => {
                const text = button.textContent || '';
                
                // Check if this is the "Outputs per prompt" button
                if (text.includes('Outputs per prompt')) {
                    // Disable the button to prevent changing
                    button.disabled = true;
                    button.style.pointerEvents = 'none';
                    button.style.opacity = '0.6';
                    button.style.cursor = 'not-allowed';
                    button.setAttribute('data-wc-locked', 'true');
                    
                    // Also find the parent container and add visual indicator
                    const parent = button.closest('div');
                    if (parent && !parent.querySelector('.wc-locked-indicator')) {
                        const indicator = document.createElement('div');
                        indicator.className = 'wc-locked-indicator';
                        indicator.style.cssText = 'font-size: 10px; color: #888; margin-top: 2px;';
                        indicator.textContent = '(Locked)';
                        parent.appendChild(indicator);
                    }
                    
                    console.log('[WC Restrict] Locked Outputs per prompt to 1');
                }
            });
            
            // Find elements with class containing "sc-4b3fbad9" (outputs selector)
            const outputSelectors = document.querySelectorAll('[class*="sc-4b3fbad9"]');
            outputSelectors.forEach(selector => {
                const text = selector.textContent || '';
                if (text.includes('Outputs per prompt')) {
                    // Find the button parent
                    const btn = selector.closest('button') || selector.querySelector('button');
                    if (btn) {
                        btn.disabled = true;
                        btn.style.pointerEvents = 'none';
                        btn.style.opacity = '0.6';
                        btn.style.cursor = 'not-allowed';
                        btn.setAttribute('data-wc-locked', 'true');
                    }
                }
            });
            
            // Hide "Outputs per prompt" dropdown options greater than 1
            const outputOptions = document.querySelectorAll('[role="option"]');
            outputOptions.forEach(option => {
                const text = option.textContent || '';
                if (text.match(/^[2-4]$/) || text === '2' || text === '4') {
                    option.style.display = 'none';
                    option.setAttribute('data-wc-hidden', 'true');
                    console.log('[WC Restrict] Hidden output option:', text);
                }
            });
            
            // Also hide the dropdown container for outputs
            const dropdowns = document.querySelectorAll('[class*="sc-4b3fbad9-0"]');
            dropdowns.forEach(dropdown => {
                const text = dropdown.textContent || '';
                if (text.includes('Outputs per prompt')) {
                    // Find the button and disable it
                    const btn = dropdown.querySelector('button') || dropdown.closest('button');
                    if (btn && !btn.getAttribute('data-wc-locked')) {
                        btn.disabled = true;
                        btn.style.pointerEvents = 'none';
                        btn.style.opacity = '0.6';
                        btn.style.cursor = 'not-allowed';
                        btn.setAttribute('data-wc-locked', 'true');
                    }
                }
            });
        }
        
        /**
         * Intercept and modify settings panel
         */
        function interceptSettingsPanel() {
            // Watch for settings panel opening
            const observer = new MutationObserver((mutations) => {
                mutations.forEach((mutation) => {
                    if (mutation.addedNodes.length) {
                        mutation.addedNodes.forEach((node) => {
                            if (node.nodeType === 1) { // Element node
                                // Check for settings panel
                                const settingsPanels = node.querySelectorAll ? 
                                    node.querySelectorAll('[class*="sc-3d54f340"], [class*="settings"], [role="dialog"]') : [];
                                
                                if (settingsPanels.length > 0 || 
                                    (node.className && typeof node.className === 'string' && 
                                     (node.className.includes('sc-3d54f340') || node.className.includes('Popover')))) {
                                    setTimeout(() => {
                                        hideRestrictedModels();
                                        forceSingleOutput();
                                    }, 100);
                                }
                                
                                // Check for model dropdown
                                const modelDropdowns = node.querySelectorAll ? 
                                    node.querySelectorAll('[class*="sc-62c7c21"], [role="listbox"]') : [];
                                
                                if (modelDropdowns.length > 0) {
                                    setTimeout(() => {
                                        hideRestrictedModels();
                                    }, 100);
                                }
                                
                                // Check for download menu
                                const downloadMenus = node.querySelectorAll ? 
                                    node.querySelectorAll('[role="menu"], [class*="download"]') : [];
                                
                                if (downloadMenus.length > 0) {
                                    setTimeout(() => {
                                        hide4KUpscaling();
                                    }, 100);
                                }
                            }
                        });
                    }
                });
            });
            
            // Start observing
            observer.observe(document.body, {
                childList: true,
                subtree: true
            });
            
            console.log('[WC Restrict] Settings panel observer started');
        }
        
        /**
         * Override model selection if user somehow selects restricted model
         */
        function interceptModelSelection() {
            document.addEventListener('click', (e) => {
                const target = e.target;
                const text = target.textContent || '';
                const parentText = target.closest('button')?.textContent || '';
                
                // Check if clicking on "Outputs per prompt" selector
                if (text.includes('Outputs per prompt') || parentText.includes('Outputs per prompt')) {
                    e.preventDefault();
                    e.stopPropagation();
                    console.log('[WC Restrict] Blocked click on Outputs per prompt - locked to 1');
                    return false;
                }
                
                // Check if clicking on a restricted model
                RESTRICTED_MODELS.forEach(model => {
                    if (text.includes(model)) {
                        e.preventDefault();
                        e.stopPropagation();
                        console.log('[WC Restrict] Blocked selection of restricted model:', model);
                        return false;
                    }
                });
                
                // Check if clicking on 4K download
                RESTRICTED_DOWNLOADS.forEach(download => {
                    if (text.includes(download) && text.length < 30) {
                        e.preventDefault();
                        e.stopPropagation();
                        console.log('[WC Restrict] Blocked 4K download option');
                        return false;
                    }
                });
                
                // Block clicks on output count options (2, 4)
                if (text.trim() === '2' || text.trim() === '4') {
                    const parent = target.closest('[role="listbox"]') || target.closest('[role="option"]');
                    if (parent) {
                        e.preventDefault();
                        e.stopPropagation();
                        console.log('[WC Restrict] Blocked output count selection:', text.trim());
                        return false;
                    }
                }
            }, true);
        }
        
        /**
         * Main initialization
         */
        function initRestrictions() {
            console.log('[WC Restrict] Initializing feature restrictions...');
            
            // Initial pass
            setTimeout(() => {
                hideRestrictedModels();
                hide4KUpscaling();
                forceSingleOutput();
            }, 1000);
            
            // Set up observers
            interceptSettingsPanel();
            interceptModelSelection();
            
            // Periodic check for dynamic content
            setInterval(() => {
                hideRestrictedModels();
                hide4KUpscaling();
                forceSingleOutput();
            }, 2000);
            
            console.log('[WC Restrict] Feature restrictions active');
        }
        
        // Wait for page to load
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', initRestrictions);
        } else {
            initRestrictions();
        }
        
        // Also run on URL change (SPA navigation)
        let lastUrl = location.href;
        new MutationObserver(() => {
            const url = location.href;
            if (url !== lastUrl) {
                lastUrl = url;
                setTimeout(initRestrictions, 1000);
            }
        }).observe(document, { subtree: true, childList: true });
        
    })();

    // =====================================================
    // CACHE SETTINGS - Save restrictions to localStorage
    // =====================================================
    
    function cacheSettings() {
        try {
            const settings = {
                restrictOutput: 'x1',
                defaultModel: 'Veo 3.1 - Fast',
                restrictedModels: ['Veo 3.1 - Quality', 'Veo 2 - Quality', 'Veo 2 - Fast', 'Veo 3 Fast', 'Veo 3 Quality'],
                timestamp: Date.now()
            };
            localStorage.setItem('wc_flow_settings', JSON.stringify(settings));
            console.log('[WC Cache] Settings cached:', settings);
        } catch (e) {
            console.log('[WC Cache] Error caching settings:', e);
        }
    }
    
    function loadCachedSettings() {
        try {
            const cached = localStorage.getItem('wc_flow_settings');
            if (cached) {
                const settings = JSON.parse(cached);
                console.log('[WC Cache] Loaded cached settings:', settings);
                return settings;
            }
        } catch (e) {
            console.log('[WC Cache] Error loading settings:', e);
        }
        return null;
    }
    
    // Initialize - cache settings on first load
    const cachedSettings = loadCachedSettings();
    if (!cachedSettings) {
        cacheSettings();
    }
    
    (function() {
        'use strict';
        
        // RESTRICT OUTPUT TABS - Only allow x1, disable x2, x3, x4
        function restrictOutputTabs() {
            // First, use CSS to hide/disable the restricted tabs
            const style = document.createElement('style');
            style.id = 'wc-restrict-tabs-style';
            if (!document.getElementById('wc-restrict-tabs-style')) {
                style.textContent = `
                    /* Disable x2, x3, x4 tabs */
                    button:has(span:contains("x2")),
                    button:has(span:contains("x3")),
                    button:has(span:contains("x4")),
                    [role="tab"]:has(span:contains("x2")),
                    [role="tab"]:has(span:contains("x3")),
                    [role="tab"]:has(span:contains("x4")),
                    .flow_tab_slider_trigger:contains("x2"),
                    .flow_tab_slider_trigger:contains("x3"),
                    .flow_tab_slider_trigger:contains("x4") {
                        display: none !important;
                    }
                    
                    /* Alternative - just disable but keep visible */
                    [data-output="x2"], [data-output="x3"], [data-output="x4"] {
                        display: none !important;
                    }
                `;
                document.head.appendChild(style);
            }
            
            // Also use JavaScript to find and disable tabs
            const allTabs = document.querySelectorAll('[role="tab"]');
            allTabs.forEach(tab => {
                const text = tab.textContent || '';
                const trimmed = text.trim();
                if (trimmed === 'x2' || trimmed === 'x3' || trimmed === 'x4') {
                    tab.style.display = 'none';
                    tab.setAttribute('data-wc-hidden', 'true');
                }
            });
            
            // Find tabs by class
            const tabButtons = document.querySelectorAll('.flow_tab_slider_trigger');
            tabButtons.forEach(tab => {
                const text = (tab.textContent || '').trim();
                if (text === 'x2' || text === 'x3' || text === 'x4') {
                    tab.style.display = 'none';
                    tab.setAttribute('data-wc-hidden', 'true');
                }
            });
            
            // Find by span/div content
            const allButtons = document.querySelectorAll('button');
            allButtons.forEach(btn => {
                const text = (btn.textContent || '').trim();
                if (text === 'x2' || text === 'x3' || text === 'x4') {
                    btn.style.display = 'none';
                    btn.setAttribute('data-wc-hidden', 'true');
                }
            });
            
            // Cache the settings
            cacheSettings();
            
            console.log('[WC Restrict] Output tabs restricted to x1 only');
        }
        
        // RESTRICT MODELS - Only allow Veo 3.1 - Fast
        function restrictModels() {
            const restrictedModels = [
                'Veo 3.1 - Quality',
                'Veo 2 - Quality',
                'Veo 2 - Fast',
                'Veo 3 Fast',
                'Veo 3 Quality'
            ];
            
            // Find all model selector buttons
            const modelButtons = document.querySelectorAll('button');
            modelButtons.forEach(btn => {
                const text = btn.textContent || '';
                
                // Check if this is a model option
                restrictedModels.forEach(model => {
                    if (text.includes(model) && !text.includes('Veo 3.1 - Fast')) {
                        // Hide or disable this model option
                        const parent = btn.closest('[role="option"]') || btn.closest('div[role="listbox"]') || btn.closest('div');
                        if (parent) {
                            parent.style.display = 'none';
                            parent.setAttribute('data-wc-model-hidden', 'true');
                        }
                        btn.style.display = 'none';
                        btn.setAttribute('data-wc-model-hidden', 'true');
                    }
                });
            });
            
            console.log('[WC Restrict] Models restricted to Veo 3.1 - Fast');
        }
        
        // SET DEFAULT OUTPUT - Ensure x1 is selected
        function setDefaultOutput() {
            // Find all tab buttons that could be output selectors
            const allButtons = document.querySelectorAll('button, [role="tab"]');
            
            allButtons.forEach(btn => {
                const text = (btn.textContent || '').trim();
                
                // Check if this is the x1 button/tab
                if (text === 'x1') {
                    // Check if it's already selected
                    const isSelected = btn.getAttribute('aria-selected') === 'true' || 
                                      btn.classList.contains('active') ||
                                      btn.getAttribute('data-state') === 'active';
                    
                    if (!isSelected) {
                        // Click to select x1
                        console.log('[WC Restrict] Selecting x1 as default output');
                        btn.click();
                    } else {
                        console.log('[WC Restrict] x1 is already selected');
                    }
                }
            });
            
            // Also check for flow_tab_slider_trigger buttons
            const tabSliders = document.querySelectorAll('.flow_tab_slider_trigger');
            tabSliders.forEach(tab => {
                const text = (tab.textContent || '').trim();
                if (text === 'x1') {
                    const isSelected = tab.getAttribute('aria-selected') === 'true' ||
                                      tab.getAttribute('data-state') === 'active';
                    if (!isSelected) {
                        console.log('[WC Restrict] Selecting x1 via tab slider');
                        tab.click();
                    }
                }
            });
        }
        
        // SET DEFAULT MODEL - Veo 3.1 - Fast
        function setDefaultModel() {
            // Find the model dropdown and ensure Veo 3.1 - Fast is selected
            const modelButtons = document.querySelectorAll('button');
            modelButtons.forEach(btn => {
                const text = btn.textContent || '';
                
                // If this is the model selector button (not an option)
                if (text.includes('Veo') && !text.includes('arrow_drop_down')) {
                    // This might be the current selection - check if it needs to be changed
                }
            });
            
            // Find dropdown option for Veo 3.1 - Fast and click it if not already selected
            const options = document.querySelectorAll('[role="option"], [role="listbox"] div');
            options.forEach(opt => {
                const text = opt.textContent || '';
                if (text.includes('Veo 3.1 - Fast') && text.includes('Lower Priority')) {
                    // This is our default model
                    console.log('[WC Restrict] Found Veo 3.1 - Fast (Lower Priority) as default');
                }
            });
        }
        
        function hideUIElements() {
            // Check if already hidden
            if (document.getElementById('wc-hide-elements-style')) {
                return;
            }
            
            // Create and inject CSS
            const style = document.createElement('style');
            style.id = 'wc-hide-elements-style';
            
            style.textContent = `
                /* Hide Flow TV link */
                a[href*="labs.google/flow/tv"],
                a[href*="flow/tv"] {
                    display: none !important;
                }
                
                /* Hide volume button */
                button[aria-label*="volume"] {
                    display: none !important;
                }
                
                /* Hide Discord link */
                a[href*="discord.com"] {
                    display: none !important;
                }
                
                /* Hide X (Twitter) link */
                a[href*="x.com"],
                a[href*="twitter.com"] {
                    display: none !important;
                }
                
                /* Hide Help button */
                button[color="BLURPLE"] {
                    display: none !important;
                }
                
                /* Hide elements by class pattern */
                i[class*="inGwPH"] {
                    display: none !important;
                }
                
                /* Hide user profile button */
                button[class*="sc-7604104e-8"],
                button[class*="sc-83a566c7-0"] {
                    display: none !important;
                }
                
                /* Hide additional elements by class */
                div[class*="sc-66302aef-0"],
                div[class*="iNNJTc"] {
                    display: none !important;
                }
                
                /* Hide toolbar container with Add Media, Scenebuilder, etc */
                div[class*="sc-c514a881-0"],
                div[class*="eSKsqH"],
                div[class*="hoeYaI"] {
                    display: none !important;
                }
                
                /* Hide ULTRA button with profile */
                div:has(> div:contains("ULTRA")) {
                    display: none !important;
                }
            `;
            
            document.head.appendChild(style);
            
            // Also use JavaScript to find and hide elements by text content
            const allButtons = document.querySelectorAll('button');
            allButtons.forEach(btn => {
                const text = btn.textContent || '';
                if (text.includes('ULTRA') || text.includes('more_vert')) {
                    btn.style.display = 'none';
                }
            });
            
            const allIcons = document.querySelectorAll('i.material-icons');
            allIcons.forEach(icon => {
                const text = icon.textContent || '';
                if (text.includes('more_vert') || text.includes('help_outlined')) {
                    const parent = icon.closest('button');
                    if (parent) parent.style.display = 'none';
                }
            });
            
            // Hide additional elements by class
            const additionalElements = document.querySelectorAll('[class*="sc-66302aef"], [class*="iNNJTc"]');
            additionalElements.forEach(el => {
                el.style.display = 'none';
            });
            
            // Hide toolbar with Add Media, Scenebuilder, More buttons
            const toolbarElements = document.querySelectorAll('[class*="sc-c514a881-0"], [class*="eSKsqH"], [class*="hoeYaI"]');
            toolbarElements.forEach(el => {
                el.style.display = 'none';
            });
            
            // Hide ULTRA button (find by text content)
            const ultraDivs = document.querySelectorAll('div');
            ultraDivs.forEach(div => {
                if (div.textContent && div.textContent.trim() === 'ULTRA') {
                    const parent = div.closest('button');
                    if (parent) parent.style.display = 'none';
                    const grandparent = div.closest('div');
                    if (grandparent) grandparent.style.display = 'none';
                }
            });
            
            // Hide buttons by their text content
            const actionButtons = document.querySelectorAll('button');
            actionButtons.forEach(btn => {
                const text = btn.textContent || '';
                if (text.includes('Add Media') || text.includes('Scenebuilder') || 
                    text.includes('View Tile Grid Settings') || text.includes('More')) {
                    btn.style.display = 'none';
                }
            });
            
            // Block clicks on restricted tabs - improved handler
            document.removeEventListener('click', window._wcTabBlockHandler);
            window._wcTabBlockHandler = function(e) {
                const target = e.target;
                let text = target.textContent || '';
                const trimmed = text.trim();
                
                // Check the clicked element
                if (trimmed === 'x2' || trimmed === 'x3' || trimmed === 'x4') {
                    e.preventDefault();
                    e.stopPropagation();
                    e.stopImmediatePropagation();
                    console.log('[WC Restrict] Blocked click on output:', trimmed);
                    return false;
                }
                
                // Check parent elements
                let current = target.parentElement;
                for (let i = 0; i < 5 && current; i++) {
                    text = current.textContent || '';
                    const parentTrimmed = text.trim();
                    
                    if (parentTrimmed === 'x2' || parentTrimmed === 'x3' || parentTrimmed === 'x4') {
                        e.preventDefault();
                        e.stopPropagation();
                        e.stopImmediatePropagation();
                        console.log('[WC Restrict] Blocked click on parent output:', parentTrimmed);
                        return false;
                    }
                    
                    // Check if it's a tab element
                    if (current.getAttribute && current.getAttribute('role') === 'tab') {
                        const ariaLabel = current.getAttribute('aria-label') || '';
                        if (ariaLabel.includes('x2') || ariaLabel.includes('x3') || ariaLabel.includes('x4')) {
                            e.preventDefault();
                            e.stopPropagation();
                            e.stopImmediatePropagation();
                            return false;
                        }
                    }
                    
                    current = current.parentElement;
                }
            };
            document.addEventListener('click', window._wcTabBlockHandler, true);
            
            console.log('[WC Hide] UI hiding styles injected');
        }
        
        // Run on page load
        setTimeout(() => {
            hideUIElements();
            restrictOutputTabs();
            restrictModels();
            setDefaultOutput();
        }, 500);
        
        // Also run when DOM changes
        const observer = new MutationObserver((mutations) => {
            setTimeout(() => {
                hideUIElements();
                restrictOutputTabs();
                restrictModels();
                setDefaultOutput();
            }, 500);
        });
        
        observer.observe(document.body, {
            childList: true,
            subtree: true
        });
        
        // Periodically check and restrict tabs and models
        setInterval(() => {
            restrictOutputTabs();
            restrictModels();
            setDefaultOutput();
        }, 2000);
        
    })();

    console.log('[Content] wakandaTools content script loaded - v12.0.0 with restrictions');
} else {
    console.log('[Content] Skipping - not on labs.google or wakandacreative.store domain');
}
